﻿namespace CustomComponents
{
  public enum ContainerType
  {
    Master = 1,
    Detail = 2
  }
}