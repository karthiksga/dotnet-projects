﻿You need to add the following fragment to the web.config file of your application:

<configuration>
    <appSettings>
	<add key="SubscriptionID" value="YOUR_AMAZON_ACCESS_KEY"/>
    </appSettings>
</configuration>