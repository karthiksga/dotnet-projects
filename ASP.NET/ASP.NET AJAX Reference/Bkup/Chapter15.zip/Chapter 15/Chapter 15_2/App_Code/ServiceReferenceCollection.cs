﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace CustomComponents
{
  public class ServiceReferenceCollection : Collection<ServiceReference>
  {
  }
}