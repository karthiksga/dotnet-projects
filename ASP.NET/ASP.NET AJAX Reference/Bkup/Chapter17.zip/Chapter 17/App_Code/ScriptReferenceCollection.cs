﻿using System.Collections.ObjectModel;
namespace CustomComponents3
{
  public class ScriptReferenceCollection : Collection<ScriptReference> { }
}